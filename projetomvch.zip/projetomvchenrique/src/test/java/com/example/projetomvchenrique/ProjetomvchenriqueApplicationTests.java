package com.example.projetomvchenrique;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetomvchenriqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
